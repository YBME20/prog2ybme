/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ni.edu.uni.programacion.backend.dao.implementation;

import com.google.gson.Gson;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import ni.edu.uni.programacion.backend.dao.VehicleDao;
import ni.edu.uni.programacion.backend.pojo.Vehicle;

/**
 *
 * @author yasser.membreno
 */
public class JsonVehicleDaoImpl extends RandomTemplate implements VehicleDao {

    private final int SIZE = 800;
    private Gson gson;

    public JsonVehicleDaoImpl() throws FileNotFoundException {
        super(new File("vehicleJson.head"), new File("vehicleJson.dat"));
        gson = new Gson();

    }

    @Override
    public Vehicle findById(int id) throws IOException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Collection<Vehicle> findByStatus(String status) throws IOException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void create(Vehicle t) throws IOException {

        getCustomRandom().getRafH().seek(0);
        int n = getCustomRandom().getRafH().readInt();
        int k = getCustomRandom().getRafH().readInt();

        long posD = k * SIZE;
        getCustomRandom().getRafD().seek(posD);

        getCustomRandom().getRafD().writeInt(++k);//id
        getCustomRandom().getRafD().writeUTF(gson.toJson(t));//Vehicle json

        long posH = 8 + (n * 8);
        getCustomRandom().getRafH().seek(posH);

        getCustomRandom().getRafH().writeInt(k);
        getCustomRandom().getRafH().writeInt(t.getStockNumber());

        getCustomRandom().getRafH().seek(0);
        getCustomRandom().getRafH().writeInt(++n);
        getCustomRandom().getRafH().writeInt(k);

        close();

    }

    @Override
    public int update(Vehicle t) throws IOException {
        //Verificar que existe stock number
        int stocknumber = t.getStockNumber();
        getCustomRandom().getRafH().seek(0);
        int n = getCustomRandom().getRafH().readInt();
        int id = 0;
        int temp = 0;

        for (int i = 0; i < n; i++) {
            long posH = 8 + (i * 8);
            //ir a la posicion 
            getCustomRandom().getRafH().seek(posH);

            id = getCustomRandom().getRafH().readInt();
            temp = getCustomRandom().getRafH().readInt();
            if (id <= 0) {
                continue;
            }

            if (stocknumber == temp) {
                long posD = (id - 1) * SIZE;
                getCustomRandom().getRafD().seek(posD);
                getCustomRandom().getRafD().readInt();
                //Sobre escribir
                getCustomRandom().getRafD().writeUTF(gson.toJson(t));//Vehicle json
                System.out.println("StockNumber " + (i + 1) + ": " + temp);
                //Retornar id del registro que actualizo
                close();
                return id;

            }
        }
        return -1;
    }

    @Override
    public boolean delete(Vehicle t) throws IOException {

        int stocknumber = t.getStockNumber();//obteniedo stacknumber del vehiculo del parametro
        int id = 0; //varaible que guardara los id leidos de la cabecera
        int stacktemp = 0; // Guardara los stachmuners de la cabecera

        //Fijando el lector de la cabecera y obteniendo la cantidad de elementos que hay
        //cantidad de id seguidos
        getCustomRandom().getRafH().seek(0);
        int n = getCustomRandom().getRafH().readInt();
        int k = getCustomRandom().getRafH().readInt();

        //Leyendo cada id y stacknumber de la cabecera
        for (int i = 0; i < n; i++) {
            long posH = 8 + (i * 8);
            getCustomRandom().getRafH().seek(posH);

            id = getCustomRandom().getRafH().readInt();
            stacktemp = getCustomRandom().getRafH().readInt();

            if (id <= 0) {
                continue;
            }

            //Verificando que existe el stacknumber del vehiculo a eliminar
            if (stocknumber == stacktemp) {
                //Al encontrar el stacknumber del vehiculo a eliminar
                //Creando archivo temporal
                File headt = new File("nuevo.head");
                RandomAccessFile rafHt = new RandomAccessFile(headt, "rw");

                //Escribiendo en el archivo temporal n - 1 y K
                rafHt.seek(0);
                rafHt.writeInt(n - 1);
                rafHt.writeInt(k);

                System.out.print((n - 1) + " - " + k + " - ");

                //Copiar cabecera actual a la nueva
                int idt = 0;
                int snt = 0;
                for (int j = 0; j < n; j++) {
                    long pos = 8 + (j * 8);
                    getCustomRandom().getRafH().seek(pos);
                    idt = getCustomRandom().getRafH().readInt();
                    snt = getCustomRandom().getRafH().readInt();

                    //Evitando escribir el id y stacknumber del objeto a "Eliminar"
                    if (idt != id) {
                        rafHt.writeInt(idt);
                        rafHt.writeInt(snt);
                        System.out.print(idt + " - " + snt + " - ");
                    }
                }
                System.out.println("");
                //Cerrando escritura en el archivo
                rafHt.close();
                close();
                //Borrando cabecera vieja
                getFileHead().delete();
                //Cambiando el nombre de la cabcera nueva al que teniea la anterior
                headt.renameTo(new File("vehicleJson.head"));

                //Retorno exitoso
                return true;
            }
        }
        return false;
    }

    @Override
    public Collection<Vehicle> getAll() throws IOException {
        List<Vehicle> vehicles = new ArrayList<>();
        Vehicle vehicle = null;

        getCustomRandom().getRafH().seek(0);
        int n = getCustomRandom().getRafH().readInt();

        for (int i = 0; i < n; i++) {
            long posH = 8 + (i * 8);
            getCustomRandom().getRafH().seek(posH);

            int id = getCustomRandom().getRafH().readInt();

            if (id <= 0) {
                continue;
            }

            long posD = (id - 1) * SIZE;
            getCustomRandom().getRafD().seek(posD);

            getCustomRandom().getRafD().readInt();
            vehicle = gson.fromJson(getCustomRandom().getRafD().readUTF(), Vehicle.class);

            vehicles.add(vehicle);
        }

        return vehicles;
    }

    public Vehicle getVehicle(int stacksearch) throws IOException {
        Vehicle v = null;
        //Cabecera
        getCustomRandom().getRafH().seek(0);
        int n = getCustomRandom().getRafH().readInt();
        int id = 0;
        int temp = 0;
        for (int i = 0; i < n; i++) {
            long posH = 8 + (i * 8);
            //ir a la posicion 
            getCustomRandom().getRafH().seek(posH);

            id = getCustomRandom().getRafH().readInt();
            temp = getCustomRandom().getRafH().readInt();
            if (id <= 0) {
                continue;
            }

            if (stacksearch == temp) {
                long posD = (id - 1) * SIZE;
                getCustomRandom().getRafD().seek(posD);
                getCustomRandom().getRafD().readInt();
                v = gson.fromJson(getCustomRandom().getRafD().readUTF(), Vehicle.class);
                
            }
        }

        return v;

    }
}
