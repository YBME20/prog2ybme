/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ni.edu.uni.programacion.views.models;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.List;
import javax.swing.table.AbstractTableModel;
import ni.edu.uni.programacion.backend.pojo.Vehicle;

/**
 *
 * @author Sistemas-05
 */
public class VehicleTableModel extends AbstractTableModel implements PropertyChangeListener {

    private List<Vehicle> data;
    private final String[] columnNames;
    
    public VehicleTableModel(List<Vehicle> data, String[] columnNames) {
        this.data = data;
        this.columnNames = columnNames;
    }
    
    public void add(Vehicle v, int posicion) {
        this.data.add(posicion, v);
        
    }
    
    public int delete(Vehicle v) {
        int indice = 0;
        for (int i = 0; i < data.size(); i++) {
            if(this.data.get(i).getStockNumber() == v.getStockNumber()){
                this.data.remove(i);
                return i;
            }
        }
        return indice;
    }
    
    @Override
    public int getRowCount() {
        return data == null ? 0 : data.size();
    }
    
    @Override
    public int getColumnCount() {
        return columnNames == null ? 0 : columnNames.length;
    }
    
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        return data == null ? null : data.isEmpty() ? null : data.get(rowIndex).asArray()[columnIndex];
    }
    
    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }
    
    @Override
    public void propertyChange(PropertyChangeEvent evt) {
        if (evt.getPropertyName().compareToIgnoreCase("new") == 0) {
            add((Vehicle) evt.getNewValue(), this.data.size());
            
        } else if (evt.getPropertyName().compareToIgnoreCase("update") == 0) {
            int pos = delete((Vehicle) evt.getOldValue());
            add((Vehicle) evt.getNewValue(), pos);
            
        }else if(evt.getPropertyName().compareToIgnoreCase("delete") == 0){
            delete((Vehicle) evt.getNewValue());
        }
        //System.out.println(evt.getPropertyName());
        fireTableDataChanged();
    }
    
}
